package com.patra

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.*
import android.print.pdf.PrintedPdfDocument
import android.text.*
import java.io.File
import java.io.FileOutputStream

data class Letter(
    val officer: String = "", val office: String = "", val subject: String = "",
    val body: String = "", val points: List<String> = emptyList(), val prayer: String = "",
    val enclosures: List<String> = emptyList(), val date: String = "",
    val name: String = "", val father: String = "", val village: String = "", val post: String = "",
    val thana: String = "", val tehsil: String = "", val block: String = "",
    val district: String = "", val mobile: String = ""
)

/** ONE renderer for preview, PDF and Print -> what you see is what you print. */
object LetterRenderer {
    const val W = 595; const val H = 842          // A4 in points (210x297 mm)
    private const val ML = 71f; private const val MT = 65f; private const val MB = 65f
    private const val GAP = 10f
    private fun v(s: String) = s.ifBlank { "____________" }

    private fun blocks(l: Letter): List<String> {
        val b = mutableListOf<String>()
        b += "सेवा में,\n${v(l.officer)}\n${v(l.office)}"
        b += "विषय: ${v(l.subject)}"
        b += "महोदय,"
        if (l.body.isNotBlank()) b += l.body
        l.points.filter { it.isNotBlank() }.forEachIndexed { i, p -> b += "${i + 1}. $p" }
        if (l.prayer.isNotBlank()) b += l.prayer
        val enc = l.enclosures.filter { it.isNotBlank() }
        if (enc.isNotEmpty()) b += "संलग्नक:\n" + enc.mapIndexed { i, e -> "${i + 1}. $e" }.joinToString("\n")
        b += "दिनांक: ${l.date.ifBlank { "__/__/____" }}"
        // प्रार्थी block: ALWAYS LEFT-aligned, kept together on one page
        b += "प्रार्थी,\nनाम: ${v(l.name)}\nपिता/पति का नाम: ${v(l.father)}\nग्राम: ${v(l.village)}\n" +
            "पोस्ट: ${v(l.post)}\nथाना: ${v(l.thana)}\nतहसील: ${v(l.tehsil)}\nब्लॉक: ${v(l.block)}\n" +
            "जनपद: ${v(l.district)}\nमोबाइल नंबर: ${v(l.mobile)}\nहस्ताक्षर: ____________"
        return b
    }

    private fun paginate(l: Letter, size: Float = 13f, spacing: Float = 1.35f): List<List<Pair<StaticLayout, Float>>> {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = size }
        val width = (W - 2 * ML).toInt()
        val pages = mutableListOf<MutableList<Pair<StaticLayout, Float>>>(mutableListOf())
        var y = MT
        for (t in blocks(l)) {
            val lay = StaticLayout.Builder.obtain(t, 0, t.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)   // LEFT, never right/center
                .setLineSpacing(0f, spacing).build()
            if (y + lay.height > H - MB && pages.last().isNotEmpty()) { pages += mutableListOf(); y = MT }
            pages.last() += lay to y
            y += lay.height + GAP
        }
        return pages
    }

    private fun drawPage(c: Canvas, items: List<Pair<StaticLayout, Float>>) {
        for ((lay, y) in items) { c.save(); c.translate(ML, y); lay.draw(c); c.restore() }
    }

    fun toBitmaps(l: Letter, scale: Float = 1.5f): List<Bitmap> = paginate(l).map { items ->
        Bitmap.createBitmap((W * scale).toInt(), (H * scale).toInt(), Bitmap.Config.ARGB_8888).also {
            val c = Canvas(it); c.drawColor(Color.WHITE); c.scale(scale, scale); drawPage(c, items)
        }
    }

    /** Real vector A4 PDF, not a stretched screenshot. */
    fun writePdf(l: Letter, out: File): File {
        val pdf = PdfDocument()
        paginate(l).forEachIndexed { i, items ->
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(W, H, i + 1).create())
            drawPage(page.canvas, items); pdf.finishPage(page)
        }
        FileOutputStream(out).use { pdf.writeTo(it) }; pdf.close(); return out
    }

    fun print(ctx: Context, l: Letter) {
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val attrs = PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()
        pm.print("Hindi Patra", object : PrintDocumentAdapter() {
            var doc: PrintedPdfDocument? = null
            override fun onLayout(o: PrintAttributes?, n: PrintAttributes, s: CancellationSignal?,
                                  cb: LayoutResultCallback, e: Bundle?) {
                doc = PrintedPdfDocument(ctx, n)
                cb.onLayoutFinished(PrintDocumentInfo.Builder("patra.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build(), true)
            }
            override fun onWrite(p: Array<PageRange>, d: ParcelFileDescriptor, s: CancellationSignal?, cb: WriteResultCallback) {
                paginate(l).forEach { items ->
                    val page = doc!!.startPage(0); drawPage(page.canvas, items); doc!!.finishPage(page)
                }
                doc!!.writeTo(FileOutputStream(d.fileDescriptor)); doc!!.close()
                cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            }
        }, attrs)
    }
}
