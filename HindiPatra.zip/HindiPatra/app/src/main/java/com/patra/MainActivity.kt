package com.patra

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme { Surface { PatraScreen() } } }
    }
}

@Composable
fun F(label: String, v: String, set: (String) -> Unit, lines: Int = 1) =
    OutlinedTextField(v, set, label = { Text(label) }, minLines = lines,
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp))

@Composable
fun PatraScreen() {
    val ctx = LocalContext.current
    var l by remember { mutableStateOf(Letter(officer = "जिलाधिकारी महोदय", points = listOf(""), enclosures = listOf(""))) }
    val pages = remember(l) { LetterRenderer.toBitmaps(l) }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("नया पत्र", style = MaterialTheme.typography.headlineSmall)
        F("अधिकारी का पद", l.officer, { l = l.copy(officer = it) })
        F("कार्यालय/जनपद", l.office, { l = l.copy(office = it) })
        F("विषय", l.subject, { l = l.copy(subject = it) })
        F("मुख्य समस्या", l.body, { l = l.copy(body = it) }, 3)
        l.points.forEachIndexed { i, p ->
            F("बिंदु ${i + 1}", p, { t -> l = l.copy(points = l.points.toMutableList().also { it[i] = t }) }, 2)
        }
        OutlinedButton({ l = l.copy(points = l.points + "") }) { Text("+ बिंदु जोड़ें") }
        F("अंतिम प्रार्थना (अतः श्रीमान से निवेदन है कि...)", l.prayer, { l = l.copy(prayer = it) }, 2)
        F("संलग्नक (एक-एक लाइन)", l.enclosures.joinToString("\n"), { l = l.copy(enclosures = it.split("\n")) }, 2)
        F("दिनांक", l.date, { l = l.copy(date = it) })
        F("आवेदक का नाम", l.name, { l = l.copy(name = it) })
        F("पिता/पति का नाम", l.father, { l = l.copy(father = it) })
        F("ग्राम", l.village, { l = l.copy(village = it) })
        F("पोस्ट", l.post, { l = l.copy(post = it) })
        F("थाना", l.thana, { l = l.copy(thana = it) })
        F("तहसील", l.tehsil, { l = l.copy(tehsil = it) })
        F("ब्लॉक", l.block, { l = l.copy(block = it) })
        F("जनपद", l.district, { l = l.copy(district = it) })
        F("मोबाइल नंबर", l.mobile, { l = l.copy(mobile = it) })

        Text("A4 Preview", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleMedium)
        pages.forEach { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().padding(vertical = 6.dp)) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ LetterRenderer.print(ctx, l) }) { Text("Print करें") }
            Button({
                val f = LetterRenderer.writePdf(l, File(ctx.cacheDir, "patra.pdf"))
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Share"))
            }) { Text("PDF / Share") }
        }
    }
}
